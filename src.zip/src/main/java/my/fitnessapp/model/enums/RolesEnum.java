package my.fitnessapp.model.enums;

public enum RolesEnum {
    USER, ADMIN;
}
