package my.fitnessapp.model.enums;

public enum RequestStatusEnum {
    PENDING,
    APPROVED,
    REJECTED;
}