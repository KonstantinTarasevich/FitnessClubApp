package my.fitnessapp.service;

public interface AdminService {
}
