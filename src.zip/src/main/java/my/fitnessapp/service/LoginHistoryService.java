package my.fitnessapp.service;

public interface LoginHistoryService {
}
